﻿using System.Data.SqlClient;

namespace FullCalander_2.Services
{
    public class Connection_services
    {
        private readonly string _connectionString;
        public Connection_services(string connectionString)
        {
            _connectionString = connectionString;
        }

        public SqlConnection OpenConnection()
        {
            var connection = new SqlConnection(_connectionString);
            connection.Open();
            return connection;
        }
        public void CloseConnection(SqlConnection connection)
        {
            if (connection != null || connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
            else
            {
                Console.WriteLine("connecton was already closed");
            }
        }

    }
}
