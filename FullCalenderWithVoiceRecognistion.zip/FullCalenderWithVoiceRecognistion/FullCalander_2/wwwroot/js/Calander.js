﻿

var allEvents = [];
var allImportantdate = [];

var calendar;
var Status;
var eventIdRem;
var eventName;
var time;
var isImportantOrNot;


$(document).ready(function () {
    console.log(allEventFromDb);
    // Initialize the calendar
    showCalender();
    //toastr.success("okk");
    setDefaultSechDates();


    AutoReminderPlay();

    //testing data 
 /*   setEvent();*/


})
function setDefaultSechDates() {
    var currentDate = moment();
    var formatedCuurentDate = moment(currentDate).format("YYYY-MM-DD");
    var oneMonthePreDate = currentDate.subtract(1, 'months');
    var currentDate = Date.now();
    var oneMonthePreDateFormat = moment(oneMonthePreDate).format("YYYY-MM-DD");
    //console.log(oneMonthePreDateFormat);
    //console.log(formatedCuurentDate);
    $("#startDateSerch").val(oneMonthePreDateFormat);
    $("#endDateSerch").val(formatedCuurentDate);
}



$("#startDateSerch").change(function (e) {
    //alert("The text has been changed.");
    var startDate = e.target.value;
    //console.log(startDate);
    $("#startDateSerch").val(startDate);

});


$("#endDateSerch").change(function (e) {
    //alert("The text has been changed.");
    var endDate = e.target.value;
    //console.log(startDate);

    $("#endDateSerch").val(endDate);
});

function showCalender() {
    var calendarEl = document.getElementById('calendar');
    // Initialize the calendar instance
    calendar = new FullCalendar.Calendar(calendarEl, {
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'timeGridWeek,dayGridMonth,multiMonthYear,listWeek',
        },

        initialView: 'dayGridMonth',
        selectable: true,
        editable: true,
        droppable: true,


        events: allEvents,
        datesSet: function (info) {
            checkImportantDateOrNot();
        },
        eventClick: function (info) {
            IsDeleteOrUpdate(info);
            console.log(info);
            //alert("Event click");
        },
        eventDrop: function (info) {
            //alert("Event drop");
            console.log(info);
            handelDrop(info)
        },
        eventResize: function (info) {
            //console.log(info);
            //alert("Event resize");
            handelResize(info.event);
        },
        select: function (info) {
            OpenModal(info);
            //alert("funcytiom");
            console.log(info);
        }
    });

    // Render the calendar after initialization
    calendar.render();

    // Once the calendar is rendered, add events
    addEventsFromDatabase();
    GettingHolidays();
}

function addEventsFromDatabase() {
    //Assuming `allEvents` is an array of events you fetched from your database
    $.each(allEventFromDb, function (idx, data) {
        var eventInDb = {
            title: data.title,
            id: data.id,
            start: data.start,
            end: data.end,
            backgroundColor: data.backgroundColor,
            editable: true,  // Make sure the event is editable
            droppable: true, // Allow the event to be dropped
        };

        if (data.isImportant == true) {
            //alert("Yes data is present ");
            //allImportantdate.push(data.start)
            //allImportantdate.push(data.end)
            updatImportntDate(data.start, data.end);
        }
        //console.log('Adding event:', eventInDb);  // Debug the event data
        allEvents.push(eventInDb);

        if (calendar) {
            calendar.addEvent(eventInDb);  // Add event to FullCalendar

        }


    });
    console.log(allImportantdate);


}

function closeModal() {
    $("#modal").hide();
}

function OpenModal(info) {

    if (allImportantdate.includes(info.startStr) || allImportantdate.includes(info.endStr)) {
        Swal.fire({
            title: "Warning can't add event to this date because its reserved ",
            icon: "warning",

        });
        return;
    }
    $("#importantDiv").show();
    Status = "Create"
    $("#eventStartTime").val(info.start);
    $("#eventEndTime").val(info.end);
    $("#eventStartDate").val(info.startStr);
    $("#eventEndDate").val(info.endStr);
    $("#eventId").val("");
    $("#eventData").val("");
    $("#eventColor").val("");
    $("#btn").text("Save");
    $("#dateShow").hide();
    $("#modal").show();
}

function editEventClick(event) {
    Status = "Edit"

    $("#eventStartDate").val(event.startStr);
    $("#eventEndDate").val(event.endStr);
    $("#eventId").val(event.id);
    $("#eventData").val(event.title);
    $("#eventColor").val(event.backgroundColor);
    $("#btn").text("Update");
    $("#dateShow").hide();
    $("#modal").show();
}

function checkIsImportant() {

    if ($("#isImortatnt").val() == false) {

    }
}
function addUpdateEvent() {

    if ($("#checkStatus").prop('checked')) {
        isImportantOrNot = true;
    }
    else {
        isImportantOrNot = false;
    }
    //alert("DDtta");
    var event = {
        title: $("#eventData").val(),
        id: $("#eventId").val(),
        start: $("#eventStartDate").val(),
        end: $("#eventEndDate").val(),
        backgroundColor: $("#eventColor").val(),
        isImportant: isImportantOrNot,

    }
    var startTime = $("#eventStartTime").val();
    var endTime = $("#eventEndTime").val();

    if (event.title == "" || event.title == null || event.backgroundColor == "" || event.backgroundColor == null) {
        Swal.fire({
            title: "Plese provide correct data ",

            text: "Full properly data",
            icon: "warning",
        });
        return false;

    }

    console.log(event);


    $.ajax({
        type: "POST",
        url: "/CalenderManagement/AddUpdateEvent",
        contantType: "application/json",
        dataType: "json",
        data: {
            id: event.id, title: event.title, start: event.start, end: event.end, backgroundColor: event.backgroundColor, startTime: startTime,
            endTime: endTime, Status: Status, isImportant: event.isImportant
        },
        success: function (res) {
            $("#modal").hide();





            if (res.taskId != 0 && res.taskId != null) {
                //alert(res.taskId);
                //var id = res.taskId;
                //console.log(id)
                var newEvent = {
                    id: res.taskId,
                    title: $("#eventData").val(),
                    end: $("#eventEndDate").val(),
                    start: $("#eventStartDate").val(),
                    backgroundColor: $("#eventColor").val(),


                };
                if (res.isImportant) {
                    updatImportntDate(res.startDate, res.endDate)
                    /* allImportantdate.push(res.date)*/
                    //checkImportantDateOrNot();
                }
                toastr.success("New event added successfully");


                allEvents.push(newEvent);
                if (calendar) {
                    calendar.addEvent(newEvent);  // Correct method to add an event
                    calendar.refetchEvents();
                }

            }
            else if (res.data == 0) {
                toastr.success("Update event successfully");
                if (calendar) {
                    var eventSelected = calendar.getEventById(event.id);
                    eventSelected.setProp('title', event.title);
                    eventSelected.setProp('backgroundColor', event.backgroundColor);
                    calendar.refetchEvents();
                }


            }
            else {
                var newEvent = {
                    id: res.taskIdWithTime,
                    title: $("#eventData").val(),
                    end: res.endTime,
                    start: res.startTime,
                    backgroundColor: $("#eventColor").val(),

                };
                toastr.success("New event added successfully");

                allEvents.push(newEvent);
                if (calendar) {
                    calendar.addEvent(newEvent);  // Correct method to add an event
                    calendar.refetchEvents();
                }


            }

        },

    })

}

function IsDeleteOrUpdate(event) {

    if (event.event.id == 0) {
        Swal.fire({
            title: "HoliDay",
            text: event.event.title,
            width: 600,
            padding: "3em",
            color: "#716add",
            background: "#fff url(/images/trees.png)",
            backdrop: `rgba(0,0,123,0.4)
    url("/images/nyan-cat.gif")
    left top
    no-repeat
  `
        });
        return;

    }

    console.log("Data for edit oe delete");
    console.log(event.event);
    var id = event.event.id;  // Use the id directly from the event object
    console.log(id);
    console.log(event.event.id);

    Swal.fire({
        title: "Want to edit or Delete this event",
        text: event.event.title,
        icon: "info",
        showDenyButton: true,
        denyButtonText: "Edit",
        showConfirmButton: true,
        confirmButtonText: "Delete",
        showCancelButton: true,
        backdrop: `rgba(0,0,123,0.4)`,
    }).then((res) => {
        if (res.isDenied) {
            // Handle Edit action
            $("#dateShow").hide();
            $("#modal").show();
            $("#importantDiv").hide();
            $("#eventId").val(event.event.id);
            $("#eventData").val(event.event.title);
            $("#eventEndDate").val(event.event.endStr);
            $("#eventStartDate").val(event.event.startStr);
            $("#eventColor").val(event.event.backgroundColor);
            $("#btn").text("Update");
        }
        else if (res.isConfirmed) {
            console.log("Dataa i ssgetteon ");
            console.log(event);
            removeImportantDate(event.event.startStr, event.event.endStr);

            checkImportantDateOrNot();
            calendar.refetchEvents();
            // Handle Delete action
            event.event.remove(); // Remove the event from the calendar
            if (calendar) {
                calendar.refetchEvents(); // Re-fetch events to update the UI
            }







            console.log(id);  // This should now print the correct id

            $.ajax({
                url: '/CalenderManagement/SoftDeleteTask',
                method: 'DELETE',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({ id: id }), // Send data as JSON string
                success: function () {
                    toastr.success('Task deleted successfully!');
                },
                error: function () {
                    toastr.error('Failed to delete task!');
                }
            });
        }
    });
}

function handelDrop(event) {

    if (allImportantdate.includes(event.event.startStr) || allImportantdate.includes(event.event.endStr)) {
        Swal.fire({
            title: "Warning can't add event to this date because its reserved ",
            icon: "warning",

        });
        event.revert();
        return;
    }


    console.log(event);
    var isImportant = allEventFromDb.find(e => e.id == event.event.id);
    var indexForEventInDb = allEventFromDb.indexOf(isImportant);

    console.log(isImportant);
    if (isImportant.isImportant == true) {
        removeImportantDate(isImportant.start, isImportant.end);
        //alert("Its important");
        updatImportntDate(event.event.startStr, event.event.endStr)
        updateDateOfEvents(indexForEventInDb, event.event.startStr, event.event.endStr);
        calendar.refetchEvents();
    }

    /*alert("jkaskd");*/
    //console.log(event.event);
    $.ajax({
        url: "/CalenderManagement/UpdatTaskDate",
        method: "PUT",
        contentType: "application/json",  // Indicate that we're sending JSON
        dataType: "json",  // Expect a JSON response from the server
        data: JSON.stringify({
            id: event.event.id,
            start: event.event.startStr,
            end: event.event.endStr,
            startTime: event.event.start,
            endTime: event.event.end
        }),
        success: function () {
            toastr.success("Update date and time of the event successfully");
            // alert("Updated task data ");
        }

    })
}

function handelResize(event) {

    console.log(allEventFromDb);
    console.log(allEvents);

    console.log(event);
    console.log("ooiaoisdooaid");
    var isImportant = allEventFromDb.find(e => e.id == event.id);

    var indexForEventInDb = allEventFromDb.indexOf(isImportant);
    console.log(indexForEventInDb);
    console.log(isImportant);
    if (isImportant.isImportant == true) {
        removeImportantDate(isImportant.start, isImportant.end);
        //alert("Its important");
        updatImportntDate(event.startStr, event.endStr);
        updateDateOfEvents(indexForEventInDb, event.startStr, event.endStr);
        calendar.refetchEvents();
    }

    $.ajax({
        url: "/CalenderManagement/EditTaskLastDate",
        method: "PUT",
        contentType: "application/json",  // Indicate that we're sending JSON
        dataType: "json",  // Expect a JSON response from the server
        data: JSON.stringify({
            id: event.id,
            end: event.endStr
        }),
        success: function () {

            console.log(allImportantdate);
            toastr.success("Update last date and last time of the event successfully");
            // alert("updated last Data");
            // alert("okk");
            //  var eventSelected = calendar.getEventById( id );
            // eventSelected.setProp('title', updatedData);
            // calendar.refetchEvents();

        }
    })
}


$("#dateSendClick").click(() => {
    if ($("#startDateSerch").val() == null || $("#startDateSerch").val() == "" || $("#endDateSerch").val() == "" || $("#endDateSerch").val() == null) {
        Swal.fire({
            title: "Plese provide correct dates ",

            text: "Choise correct date",
            icon: "warning",
        });
        return false;
    }
})

function GettingHolidays() {
    fetch('https://api.11holidays.com/v1/holidays?country=IN&year=2024').
        then((res) => {
            /* console.log(res.json());*/
            res.json().then((data) => {
                //console.log("data");
                //console.log(data);
                const holidays = data.map((holiday) => ({
                    id: 0,
                    title: holiday.name,
                    start: holiday.date,
                    end: holiday.date,
                    backgroundColor: '#0B8043',
                    borderColor: '#0B8043',
                    editable: false,
                    droppable: false,
                    eventClick: false
                }));
                //console.log("map");
                //console.log(holidays);
                holidays.forEach((holiday) => {
                    calendar.addEvent(holiday); // Add each holiday event to FullCalendar
                });


            })
        })
}


$("#remainderBox").click(() => {
    $("#reminerModal").show();
})
function reminderModalClose() {
    $("#reminerModal").hide();
}

$("#eventIdRem").change((e) => {

    eventIdRem = e.target.value;

    console.log(e.target.value);
    console.log(e.target.name);
    console.log(eventName);
    console.log(e.target);
})
$("#remiderTime").change((e) => {
    time = e.target.value;
    //alert("OKk");
    console.log(e.target);
    console.log(e.target.value);
    console.log(e.target.name);
})
//function changerTime() {
//    alert("okk");
//}
function addUpdateReminder() {

    eventName = $("#eventIdRem option:selected").text();

    var reminderTime = {
        eventId: eventIdRem, time: time, name: eventName
    }
    if (reminderTime.time == "" || reminderTime.time == null) {
        //alert("Time");
        var currDate = new Date();
        var currentHour = currDate.getHours().toString().padStart(2, "0");;
        var currentMint = currDate.getMinutes().toString().padStart(2, "0");;
        var currFullTime = currentHour + ":" + currentMint;
        reminderTime.time = currFullTime;
        console.log("cuurengtassa", currFullTime);
        $("#remiderTime").val(currFullTime);
    }
    if (reminderTime.eventId == null || reminderTime.time == 0) {
        var firstEvent = allEventFromDb[0];
        reminderTime.eventId = firstEvent.id;
        console.log(firstEvent);
    }

    console.log(reminderTime);
    console.log(eventIdRem);
    console.log(time);
    console.log(eventName);
    $.ajax({
        url: '/CalenderManagement/addUpdateReminder',
        method: "POST",
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(reminderTime),
        success: function (response) {
            //alert("Reminder added/updated successfully!");
            $("#reminerModal").hide();  // Assuming this is a modal you want to hide after success
            toastr.success(response.message);  // Assuming you have toastr configured for notifications
            setTimeout(() => {
                window.location.reload();
            }, 2000);

        },
    })
}


var timeIntervalId;
function AutoReminderPlay() {

    if (timeIntervalId) {
        clearInterval(timeIntervalId);
    }
    timeIntervalId = setInterval(() => {
        var alarm = document.getElementById("alarmMusic");
        //console.log(allReminderFromDb);
        $.each(allReminderFromDb, (idx, remider) => {
            var currentDate = new Date();
            var currentHours = currentDate.getHours().toString().padStart(2, "0");;
            var currentMints = currentDate.getMinutes().toString().padStart(2, "0");;
            var FullTime = currentHours + ":" + currentMints;

            console.log(FullTime);
            if (remider.time === FullTime) {
                alarm.play();
                Swal.fire({
                    title: "Alarm For Your Task",
                    text: remider.name,
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Stop Alarm!!!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        alarm.pause();
                        //alert("Data");
                        //clearInterval(timeIntervalId);
                        softDeleteReminder(remider.id);

                    }
                });
            }
        })
    }, 10000)
}

function softDeleteReminder(id) {
    $.ajax({
        url: '/CalenderManagement/SoftDeleteReminder',
        method: 'DELETE',
        contentType: 'application/json',
        dataType: 'json',
        data: JSON.stringify({ id: id }), // Send data as JSON string
        success: function () {
            clearInterval(timeIntervalId);
            toastr.success('Reminder Off  successfully!');
            setTimeout(() => {
                window.location.reload();
            }, 2000)
        },
        error: function () {
            toastr.error('Failed to off reminder');
        }
    });
}




function updatImportntDate(startDateForBg, endDateForBg) {
    //var backUpInpDates = [...allImportantdate];
    //allImportantdate = [];
    //console.log("All aray data ")
    //console.log(allImportantdate);

    let startDate = new Date(startDateForBg);
    let endDate = new Date(endDateForBg);
    while (startDate < endDate) {
        var dateForEvent = moment(startDate).format("YYYY-MM-DD");
        allImportantdate.push(dateForEvent.toString());
        console.log("Date exists");
        startDate.setDate(startDate.getDate() + 1);
    }

    checkImportantDateOrNot();//$.each(allEventFromDb, function (idx, data) {
}



function removeImportantDate(startDateForRem, endDateForRem) {
    console.log(allImportantdate);
    console.log(startDateForRem)
    console.log(endDateForRem)
    console.log("Remove is working ")

    var backUpInpDates = [...allImportantdate];
    //allImportantdate = [];
    //console.log("All aray data ")
    //console.log(allImportantdate);

    let startDate = new Date(startDateForRem);
    let endDate = new Date(endDateForRem);



    while (startDate < endDate) {
        var dateForEvent = moment(startDate).format("YYYY-MM-DD");
        console.log(dateForEvent);
        //allImportantdate.remove(dateForEvent.toString());
        var index = (allImportantdate.indexOf(dateForEvent.toString()));
        allImportantdate.splice(index, 1);
        console.log(index);
        console.log("Remove data ");

        startDate.setDate(startDate.getDate() + 1);
    }


    //checkImportantDateOrNot();//$.each(allEventFromDb, function (idx, data) {
}


function checkImportantDateOrNot() {
    calendar.refetchEvents();
    // This runs every time the calendar is re-rendered
    //console.log(info);          // Outputs the info object with details about the rendered dates
    //// Your custom logic goes here, for example, styling specific dates
    //// For now, the alert will trigger every time the view is rendered
    //console.log("Rendering calendar...");

    var currentDateChck = new Date;
    var formatedDate = moment(currentDateChck).format("YYYY-MM-DD");

    var cells = document.querySelectorAll('.fc-daygrid-day');
    $.each(cells, (idx, date) => {
        var currentDate = date.getAttribute('data-date');

        if (allImportantdate.includes(currentDate)) {
            date.style.backgroundColor = 'lightyellow';
        }
        else if (formatedDate == currentDate) {
            date.style.backgroundColor = 'lightblue';
        }
        else {
            date.style.backgroundColor = 'white';
        }
    })
    calendar.refetchEvents();
}


function updateDateOfEvents(idx, startdate, enddate) {
    console.log("Here get ")
    console.log(idx);
    console.log(startdate);
    console.log(enddate);
    console.log(allEventFromDb);
    allEventFromDb[idx].start = startdate;
    allEventFromDb[idx].end = enddate;
}


//speech reognition

const micBtn = document.getElementById("micBtn");
const output = document.getElementById("output");

// Check if browser supports SpeechRecognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (!SpeechRecognition) {
    output.innerHTML = "Speech Recognition is not supported in your browser.";
} else {
    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.continuous = false;

    micBtn.addEventListener("click", () => {
        recognition.start();
    });

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        output.innerHTML = `You said: ${transcript}`;
        setEvent(transcript);
        //console.log(transcript);
    };

    recognition.onerror = (event) => {
        output.innerHTML = `Error: ${event.error}`;
    };
}


function setEvent(completeText) {
    console.log(completeText);

    var text = "One February 2025 party"; // Input text
    var text2 = "One January 2025 party"; // Input text

    // Updated regex to capture only the date and event
    const regex = /((?:One|Two|Three|Four|Five|Six|Seven|Eight|Nine|Ten|Eleven|Twelve)\s\w+\s\d{4})\s+(\w+)/i;


    // Apply the regular expression to extract date, event, and color
    const match = completeText.match(regex);

    if (match) {
        // Extract matched groups
        let date = match[1];       // Date (e.g., "One February 2024")
        const event = match[2];     // Event (e.g., "party")

        // Debugging: Log the extracted values
        console.log("Extracted Date: ", date);
        console.log("Extracted Event: ", event);

        // Convert word-based date to a numeric format (e.g., "One" to "1")
        const wordToNumber = {
            "One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5,
            "Six": 6, "Seven": 7, "Eight": 8, "Nine": 9, "Ten": 10,
            "Eleven": 11, "Twelve": 12
        };
        var formatedStartDate = moment(date).format("YYYY-MM-DD");
        var endDate = moment(formatedStartDate).add(1, "day");

        var formatedEndDate = moment(endDate).format("YYYY-MM-DD");
        console.log(formatedStartDate);
        console.log(formatedEndDate);

        $("#importantDiv").show();
        Status = "Create";
        $("#eventStartDate").val(formatedStartDate);
        $("#eventEndDate").val(formatedEndDate);
       
        $("#eventData").val(event);
        $("#eventDataByVoice").val(formatedStartDate);
        $("#btn").text("Save");
        $("#dateShow").show();
        $("#modal").show();





    }
    else {
        Swal.fire({
            title: "Incorect format of data please provide correct data !!!!",
            text: "Date-Event"
        });
        return;
    }

   
}
