﻿namespace FullCalander_2.Models
{
    public class ReminderTime
    {
        public int id{ get; set; }
        public int eventId { get; set; }
        public string time { get; set; }
        public string name { get; set; }
    }
}
