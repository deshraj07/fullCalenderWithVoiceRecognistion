﻿namespace FullCalander_2.Models
{
    public class EventsRreminderVM
    {
        public IEnumerable<Event> AllEvent { get; set; }
        public IEnumerable<ReminderTime> ReminderTimes{ get; set; }
    }
}
