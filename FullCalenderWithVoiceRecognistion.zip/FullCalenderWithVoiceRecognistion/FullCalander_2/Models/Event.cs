﻿using Microsoft.AspNetCore.Identity;

namespace FullCalander_2.Models
{
    public class Event
    {
        public int id { get; set; }
        public string title { get; set; }
        public string backgroundColor { get; set; }
        public string start { get; set; }
        public string end { get; set; }
        public string Status { get; set; }
        public string startTime { get; set; }
        public string endTime { get; set; }
        public bool isImportant { get; set; }
    }
}
