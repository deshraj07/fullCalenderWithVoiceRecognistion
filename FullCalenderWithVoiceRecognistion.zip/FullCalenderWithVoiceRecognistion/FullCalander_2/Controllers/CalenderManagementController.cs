﻿using System.Data.SqlClient;
using System.Data;
using FullCalander_2.Models;
using FullCalander_2.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System.Security.Cryptography.Pkcs;

namespace FullCalander_2.Controllers
{
	public class CalenderManagementController : Controller
	{
		private readonly Connection_services _connection;
		public CalenderManagementController(Connection_services connection)
		{
			_connection = connection;
		}


		[HttpGet]
		public IActionResult Index()
		{


			var allEvents = new List<Event>();

			using (var connection = _connection.OpenConnection())
			{
				var command = new SqlCommand("GetAllEvent", connection);
				command.CommandType = CommandType.StoredProcedure;
				using (var reader = command.ExecuteReader())
				{
					while (reader.Read())
					{
						var data = reader.GetString(6);

						var strstartDate = (reader.GetDateTime(2));
						var strEndDate = reader.GetDateTime(3);
						var newEvent = new Event
						{
							id = reader.GetInt32(0),
							title = reader.GetString(1),
							backgroundColor = reader.GetString(5),
							isImportant = reader.GetBoolean(8),


						};
						if (data != "0")
						{
							newEvent.start = reader.GetString(6);
							newEvent.end = reader.GetString(7);
						}
						else
						{

							newEvent.start = reader.GetDateTime(2).ToString("yyyy-MM-dd");
							newEvent.end = reader.GetDateTime(3).ToString("yyyy-MM-dd");
						}


						allEvents.Add(newEvent);

					}
				}

			}



			var allReminders = new List<ReminderTime>();

			using (var connection = _connection.OpenConnection())
			{
				var command = new SqlCommand("GetAllReminderTime", connection);
				command.CommandType = CommandType.StoredProcedure;
				using (var reader = command.ExecuteReader())
				{
					while (reader.Read())
					{

						var newRemnder = new ReminderTime
						{
							id = reader.GetInt32(0),
							eventId = reader.GetInt32(1),
							time = reader.GetString(2),
							name = reader.GetString(4),


						};


						allReminders.Add(newRemnder);

					}
				}

			}


			var allEventsAndReminders = new EventsRreminderVM
			{
				AllEvent = allEvents,
				ReminderTimes = allReminders
			};
			return View(allEventsAndReminders);
		}


		[HttpPost]
		public IActionResult AddUpdateEvent(Event @event)
		{


			if (@event.id == 0 || @event.id == null)
			{



				string startDateTimeString = @event.start;
				string endDateTimeString = @event.end;

				DateTime dateTimeStart = DateTime.Parse(startDateTimeString);
				DateTime dateTimeEnd = DateTime.Parse(endDateTimeString);

				DateTime datePartStart = dateTimeStart.Date;  // This gives the date part (2024-12-24)
				DateTime datePartEnd = dateTimeEnd.Date;  // This gives the date part (2024-12-24)

				// Extract Time
				TimeSpan timePartStart = dateTimeStart.TimeOfDay;
				TimeSpan timePartEnd = dateTimeEnd.TimeOfDay;
				if (timePartStart != TimeSpan.Zero || timePartEnd != TimeSpan.Zero)
				{
					using (var connection = _connection.OpenConnection())
					{
						var command = new SqlCommand("AddTaskWithTime", connection);
						command.CommandType = CommandType.StoredProcedure;
						command.Parameters.AddWithValue("@Task", @event.title);
						command.Parameters.AddWithValue("@backgroundColor", @event.backgroundColor);
						command.Parameters.AddWithValue("@startTime", @event.start);
						command.Parameters.AddWithValue("@EndTime", @event.end);
						command.Parameters.AddWithValue("@StartDate", @event.start);
						command.Parameters.AddWithValue("@EndDate", @event.end);
						command.Parameters.AddWithValue("@IsImportant", @event.isImportant);
						command.ExecuteNonQuery();
					}
					//var updatedData ={title: title, ;

					using (var connection = _connection.OpenConnection())
					{
						var command = new SqlCommand("GetTaskIdBtTime", connection);
						command.CommandType = CommandType.StoredProcedure;
						command.Parameters.AddWithValue("@Task", @event.title);
						command.Parameters.AddWithValue("@StartTime", @event.start);
						command.Parameters.AddWithValue("@EndTime", @event.end);
						var taskIdWithTime = command.ExecuteScalar();
						_connection.CloseConnection(connection);

						return Json(new { message = "event Added successfully", startTime = @event.start, endTime = @event.end, taskIdWithTime = taskIdWithTime });
					}


				}
			}


			if (@event.id != 0)
			{
				using (var connection = _connection.OpenConnection())
				{
					var command = new SqlCommand("EditTask", connection);
					command.CommandType = CommandType.StoredProcedure;
					command.Parameters.AddWithValue("@Id", @event.id);
					command.Parameters.AddWithValue("@Task", @event.title);
					command.Parameters.AddWithValue("@backgroundColor", @event.backgroundColor);
					command.ExecuteNonQuery();
				}
				//var updatedData ={title: title, ;
				return Json(new { data = 0 });
				//return RedirectToAction("Index");
			}
			else
			{

				//var startDate = DateTime.Parse(@event.start);
				//var endDate = DateTime.Parse(@event.end);
				using (var connection = _connection.OpenConnection())
				{
					var command = new SqlCommand("AddTask", connection);
					command.CommandType = CommandType.StoredProcedure;
					command.Parameters.AddWithValue("@Task", @event.title);
					command.Parameters.AddWithValue("@StartDate", @event.start);
					command.Parameters.AddWithValue("@EndDate", @event.end);
					command.Parameters.AddWithValue("@backgroundColor", @event.backgroundColor);
					command.Parameters.AddWithValue("@IsImportant", @event.isImportant);
					command.ExecuteNonQuery();
					_connection.CloseConnection(connection);
				}



				using (var connection = _connection.OpenConnection())
				{
					var command = new SqlCommand("GetTaskId", connection);
					command.CommandType = CommandType.StoredProcedure;
					command.Parameters.AddWithValue("@Task", @event.title);
					command.Parameters.AddWithValue("@StartDate", @event.start);
					command.Parameters.AddWithValue("@EndDate", @event.end);
					var taskId = command.ExecuteScalar();
					_connection.CloseConnection(connection);
					return Json(new { taskId = taskId, isImportant = @event.isImportant, startDate = @event.start, endDate = @event.end });
				}

				//sending the id 
				//return RedirectToAction("Index");
			}
		}



		[HttpDelete]
		public IActionResult SoftDeleteTask([FromBody] Event @event)
		{

			using (var connection = _connection.OpenConnection())
			{
				var command = new SqlCommand("SoftDeleteTask", connection);
				command.CommandType = CommandType.StoredProcedure;
				command.Parameters.AddWithValue("@Id", @event.id);

				command.ExecuteNonQuery();
			}
			return new JsonResult(new { success = true, message = "data deleted successfully" });

		}


		[HttpPut]
		public IActionResult UpdatTaskDate([FromBody] Event @event)
		{


			string startDateTimeString = @event.start;
			string endDateTimeString = @event.end;

			DateTime dateTimeStart = DateTime.Parse(startDateTimeString);
			DateTime dateTimeEnd = DateTime.Parse(endDateTimeString);

			DateTime datePartStart = dateTimeStart.Date;  // This gives the date part (2024-12-24)
			DateTime datePartEnd = dateTimeEnd.Date;  // This gives the date part (2024-12-24)

			// Extract Time
			TimeSpan timePartStart = dateTimeStart.TimeOfDay;
			TimeSpan timePartEnd = dateTimeEnd.TimeOfDay;

			if (timePartStart != TimeSpan.Zero || timePartEnd != TimeSpan.Zero)
			{
				using (var connection = _connection.OpenConnection())
				{
					var command = new SqlCommand("UpdatTaskTime", connection);
					command.CommandType = CommandType.StoredProcedure;
					command.Parameters.AddWithValue("@Id", @event.id);
					command.Parameters.AddWithValue("@StartTime", @event.start);
					command.Parameters.AddWithValue("@EndTime", @event.end);
					command.ExecuteNonQuery();
				}
			}
			//if (@event.end == null || @event.end == "")
			//{
			//    using (var connection = _connection.OpenConnection())
			//    {
			//        var command = new SqlCommand("EditTaskStartDate", connection);
			//        command.CommandType = CommandType.StoredProcedure;
			//        command.Parameters.AddWithValue("@Id", @event.id);
			//        command.Parameters.AddWithValue("@StartDate", @event.start);

			//        command.ExecuteNonQuery();
			//    }
			//    return new JsonResult(new { message = "data added successfully" });
			//}

			//var startDate = DateTime.Parse(@event.start);
			//var endDate = DateTime.Parse(@event.end);
			else
			{

				using (var connection = _connection.OpenConnection())
				{
					var command = new SqlCommand("UpdatTaskDate", connection);
					command.CommandType = CommandType.StoredProcedure;
					command.Parameters.AddWithValue("@Id", @event.id);
					command.Parameters.AddWithValue("@StartDate", @event.start);
					command.Parameters.AddWithValue("@EndDate", @event.end);
					command.ExecuteNonQuery();
				}
			}
			return new JsonResult(new { message = "data added successfully" });
			//return RedirectToAction("Index");

		}


		[HttpPut]
		public IActionResult EditTaskLastDate([FromBody] Event @event)
		{

			string endDateTimeString = @event.end;

			DateTime dateTimeEnd = DateTime.Parse(endDateTimeString);

			DateTime datePartEnd = dateTimeEnd.Date;  // This gives the date part (2024-12-24)

			// Extract Time
			TimeSpan timePartEnd = dateTimeEnd.TimeOfDay;

			if (timePartEnd != TimeSpan.Zero)
			{
				using (var connection = _connection.OpenConnection())
				{
					var command = new SqlCommand("EditTaskLastTime", connection);
					command.CommandType = CommandType.StoredProcedure;
					command.Parameters.AddWithValue("@Id", @event.id);
					command.Parameters.AddWithValue("@EndTime", @event.end);

					command.ExecuteNonQuery();
				}
			}
			else
			{
				using (var connection = _connection.OpenConnection())
				{
					var command = new SqlCommand("EditTaskLastDate", connection);
					command.CommandType = CommandType.StoredProcedure;
					command.Parameters.AddWithValue("@Id", @event.id);
					command.Parameters.AddWithValue("@EndDate", @event.end);

					command.ExecuteNonQuery();
				}
			}
			return new JsonResult(new { success = true, message = "data date expand  successfully" });

		}


		[HttpPost]
		public IActionResult FindEventsBetweenDates(DateTime startDateSerch, DateTime endDateSerch)
		{

			var allEvents = new List<Event>();

			using (var connection = _connection.OpenConnection())
			{
				var command = new SqlCommand("GetTaskBtwDates", connection);
				command.CommandType = CommandType.StoredProcedure;
				command.Parameters.AddWithValue("@StartDate", startDateSerch);
				command.Parameters.AddWithValue("@EndDate", endDateSerch);
				using (var reader = command.ExecuteReader())
				{
					while (reader.Read())
					{
						var strstartDate = (reader.GetDateTime(2));
						var strEndDate = reader.GetDateTime(3);
						var newEvent = new Event
						{
							id = reader.GetInt32(0),
							title = reader.GetString(1),
							start = strstartDate.ToString("yyyy-MM-dd"),
							end = strEndDate.ToString("yyyy-MM-dd"),
							backgroundColor = reader.GetString(5),


						};
						allEvents.Add(newEvent);

					}
				}

			}

			return View(allEvents);


		}

		[HttpPost]
		public IActionResult addUpdateReminder([FromBody] ReminderTime reminderTime)
		{

			if (reminderTime.id != 0)
			{
				using (var connection = _connection.OpenConnection())
				{
					var command = new SqlCommand("EditReminderTime", connection);
					command.CommandType = CommandType.StoredProcedure;
					command.Parameters.AddWithValue("@Id", reminderTime.id);
					command.Parameters.AddWithValue("@Time", reminderTime.time);

					command.ExecuteNonQuery();
				}
				return new JsonResult(new { success = true, message = "Reminder time updated  successfully", updatedTime = reminderTime.time });

				//return RedirectToAction("GetAllReminder");
			}
			using (var connection = _connection.OpenConnection())
			{
				var command = new SqlCommand("AddReminderTime", connection);
				command.CommandType = CommandType.StoredProcedure;
				command.Parameters.AddWithValue("@EventId", reminderTime.eventId);
				command.Parameters.AddWithValue("@RemainderTime", reminderTime.time);
				command.Parameters.AddWithValue("@EventName", reminderTime.name);
				command.ExecuteNonQuery();
			}
			return Json(new { suceess = true, message = "Add reminder successfully" });
		}
		[HttpGet]
		public IActionResult GetAllReminder(bool isDelete)
		{

			if (isDelete)
			{
				ViewBag.deleteMessage = "Deleted data successfully";
			}
			else
			{
				ViewBag.deleteMessage = "";
			}


			var allReminders = new List<ReminderTime>();

			using (var connection = _connection.OpenConnection())
			{
				var command = new SqlCommand("GetAllReminderTime", connection);
				command.CommandType = CommandType.StoredProcedure;
				using (var reader = command.ExecuteReader())
				{
					while (reader.Read())
					{

						var newRemnder = new ReminderTime
						{
							id = reader.GetInt32(0),
							eventId = reader.GetInt32(1),
							time = reader.GetString(2),
							name = reader.GetString(4),


						};


						allReminders.Add(newRemnder);

					}
				}

			}

			return View(allReminders);
		}

		[HttpDelete]
		public IActionResult SoftDeleteReminder([FromBody] ReminderTime reminderTime)
		{
			using (var connection = _connection.OpenConnection())
			{
				var command = new SqlCommand("SoftDeleteReminder", connection);
				command.CommandType = CommandType.StoredProcedure;
				command.Parameters.AddWithValue("@Id", reminderTime.id);

				command.ExecuteNonQuery();
			}
			return new JsonResult(new { success = true, message = "data deleted successfully" });

			//return RedirectToAction("Index");
		}

		//[HttpPut]
		//public IActionResult EditReminderTime( int id , string reminderTime)
		//{

		//} 


		//public IActionResult DeleteReminderTime( int id )
		//{
		//    using (var connection = _connection.OpenConnection())
		//    {
		//        var command = new SqlCommand("SoftDeleteReminder", connection);
		//        command.CommandType = CommandType.StoredProcedure;
		//        command.Parameters.AddWithValue("@Id", id);


		//        command.ExecuteNonQuery();
		//    }
		//    //return new JsonResult(new { success = true, message = "Reminder time deleted  successfully" });

		//    return RedirectToAction("GetAllReminder",new {isDelete = true});
		//}

		[HttpGet]
		public IActionResult GetAlleventWithImpDate()
		{
			var allEvents = new List<Event>();

			using (var connection = _connection.OpenConnection())
			{
				var command = new SqlCommand("GetAllEventWithImpDate", connection);
				command.CommandType = CommandType.StoredProcedure;
				using (var reader = command.ExecuteReader())
				{
					while (reader.Read())
					{
						var data = reader.GetString(6);

						var strstartDate = (reader.GetDateTime(2));
						var strEndDate = reader.GetDateTime(3);
						var newEvent = new Event
						{
							id = reader.GetInt32(0),
							title = reader.GetString(1),
							backgroundColor = reader.GetString(5),
							isImportant = reader.GetBoolean(8),


						};
						if (data != "0")
						{
							newEvent.start = reader.GetString(6);
							newEvent.end = reader.GetString(7);
						}
						else
						{

							newEvent.start = reader.GetDateTime(2).ToString("yyyy-MM-dd");
							newEvent.end = reader.GetDateTime(3).ToString("yyyy-MM-dd");
						}


						allEvents.Add(newEvent);

					}
				}

			}
			return View(allEvents);

		}
		
		public IActionResult RemoveImpDate(int id)
		{



			using (var connection = _connection.OpenConnection())
			{
				var command = new SqlCommand("removeEventFromImpList", connection);
				command.CommandType = CommandType.StoredProcedure;
				command.Parameters.AddWithValue("@Id", id);

				command.ExecuteNonQuery();
			}


			return RedirectToAction("GetAlleventWithImpDate");

		}


		public IActionResult VoiceToText()
		{
			return View();
		}
	}
}
